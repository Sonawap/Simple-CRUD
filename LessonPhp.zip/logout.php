<?php
require_once('php/User.php');

$user->logout();