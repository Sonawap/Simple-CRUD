<?php 
	require_once('php/User.php');
?>
<!Doctype html>
<head>
	<title>Welcome</title>
</head>

<?php require_once('pages/nav.php'); ?>
